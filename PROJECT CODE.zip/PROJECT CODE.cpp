#include <iostream>
#include <string.h>
#include <fstream>
#include <iomanip>
#include <conio.h>
#include <stdlib.h>
using namespace std;

class project12;
class Data;
class project10
{
    char a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,choice3,c22;
    int s,c,a,choice,c23,c24,c25,c26;
    string name;
    int standard,goback;
    double percentage;

public:
    project10()
    {
        c22='Y';
        a1='Y';
        a2='Y';
        a3='Y';
        a4='Y';
        a5='Y';
        a6='Y';
        a7='Y';
        a8='Y';
        a9='Y';
        a10='Y';
        a11='Y';
        s=0;
        a=0;
        c=0;
        name="sohampatel";
        standard=0;
        percentage=0.0;
    }

    void input10()
    {
        system("cls");
        cout<<"\nMandatory details to be filled by the student"<<endl;
        cout<<"\n10th std percentage:"<<endl;
        cin>>percentage;
        cout<<"\nDo you want to give an Aptitude test?\n'Y'-for yes & 'N'-for no"<<endl;
        cin>>choice3;
        while(!((choice3=='Y')||(choice3=='y')||(choice3=='N')||(choice3=='n')))
        {
            cout<<"Invalid Input!"<<endl;
            cout<<"Enter your choice again!";
            cin>>choice3;
        }
        if(choice3=='Y' || choice3=='y')
        {
            mcq();
        }
        else
        {
            homepage10();
        }
    }
    void homepage10()
    {
        system("cls");
        cout<<"Streams available:\n1.Science\n2.Commerce\n3.Arts"<<endl;
        cin>>c23;
        while(!((c23==1)||(c23==2)||(c23==3)))
        {
            cout<<"Wrong input!"<<endl;
            cout<<"Enter again:"<<endl;
            cin>>c23;
        }
        if(c23==1)
        {
            Science();
        }
        if(c23==2)
        {
            Commerce();
        }
        if(c23==3)
        {
            Arts();
        }
    }
    void exitgoback()
    {
        cout<<"\n\n1.Exit\n2.Go back\n";
        cin>>goback;
        while(!((goback==1)||(goback==2)))
        {
            cout<<"\nInvalid Input!";
            cout<<"\nEnter again:"<<endl;
            cin>>goback;
        }
        if(goback==1)
        {
            cout<<"\n\nThank you! Do visit again!";
        }
        if(goback==2)
        {
            homepage10();
        }
    }
    void mcq()
    {
        system("cls");
        cout<<"Below are some basic questions. Press 'Y' for Yes and 'N' for No\n";
        cout<<"\nDo you feel confident in handling other people's money?\n";
        cout<<"Ans: ";
        cin>>a1;
        cout<<"\nDo you enjoy reading technical material and solve technical problems?\n";
        cout<<"Ans: ";
        cin>>a2;
        cout<<"\nDo you enjoy working in a laboratory and experimenting?\n";
        cout<<"Ans: ";
        cin>>a3;
        cout<<"\nDo you like reading business newspapers?\n";
        cout<<"Ans: ";
        cin>>a4;
        cout<<"\nDo you think working in a hospital or medical facilities is a bad idea?\n";
        cout<<"Ans: ";
        cin>>a5;
        cout<<"\nDo you like to spend time in library collecting information about the world history, evolution, etc?\n";
        cout<<"Ans: ";
        cin>>a6;
        cout<<"\nDo you find it exciting to learn how things grow and stay alive?\n";
        cout<<"Ans: ";
        cin>>a7;
        cout<<"\nDo you show strong interest in how law and regulations are designed and passed?\n";
        cout<<"Ans: ";
        cin>>a8;
        cout<<"\nDo you find it boring to learn chemical formulas and physics theory?\n";
        cout<<"Ans: ";
        cin>>a9;
        cout<<"\nCan you analyze financial information and interpret it to others?\n";
        cout<<"Ans: ";
        cin>>a10;
        cout<<"\nDo you find new technologies exciting?\n";
        cout<<"Ans: ";
        cin>>a11;
        process();
    }
    void process()
    {
        if(a1=='Y'||a1=='y')
        {
            c++;
        }
        else
        {
            s++;
            a++;
        }
        if(a2=='Y'||a2=='y')
        {
            s++;
        }
        else
        {
            c++;
            a++;
        }
        if(a3=='Y'||a3=='y')
        {
            s++;
        }
        else
        {
            c++;
            s++;
        }
        if(a4=='Y'||a4=='y')
        {
            c++;
        }
        else
        {
            s++;
            a++;
        }
        if(a5=='Y'||a5=='y')
        {
            a++;
            c++;
        }
        else
        {
            s++;
        }
        if(a6=='Y'||a6=='y')
        {
            a++;
        }
        else
        {
            c++;
            s++;
        }
        if(a7=='Y'||a7=='y')
        {
            s++;
        }
        else
        {
            c++;
            a++;
        }
        if(a8=='Y'||a8=='y')
        {
            a++;
        }
        else
        {
            s++;
            c++;
        }
        if(a9=='Y'||a9=='y')
        {
            a++;
            c++;
        }
        else
        {
            s++;
        }
        if(a10=='Y'||a10=='y')
        {
            c++;
        }
        else
        {
            a++;
            s++;
        }
        if(a11=='Y'||a11=='y')
        {
            s++;
        }
        else
        {
            a++;
            c++;
        }
        if(s>=c && s>=a)
        {
            system("cls");
            cout<<"\nAccording to the Aptitude test you would be having some interest in Science."<<endl;
            cout<<"\nWould you like to see some Colleges related to Science?\n1.Yes\n2.No\n";
            cin>>c24;
            while(!((c24==1)||(c24==2)))
            {
                cout<<"Invalid Input!"<<endl;
                cout<<"Enter again:"<<endl;
                cin>>c24;
            }
            if(c24==1)
            {
                Science();
            }
            else if(c24==2)
            {
                homepage10();
            }

        }
        if(c>=a && c>=s)
        {
            cout<<"\nAccording to the Aptitude test you would be having some interest in Commerce."<<endl;
            cout<<"\nWould you like to see some Colleges related to Commerce?\n1.Yes\n2.No\n";
            cin>>c25;
            while(!((c25==1)||(c25==2)))
            {
                cout<<"Invalid Input!"<<endl;
                cout<<"Enter again:"<<endl;
                cin>>c25;
            }
            if(c25==1)
            {
                Commerce();
            }
            else if(c25==2)
            {
                homepage10();
            }

        }
        if(a>=s && a>=c)
        {
             cout<<"\nAccording to the Aptitude test you would be having some interest in Arts.";
             cout<<"\nWould you like to see some Colleges related to science?\n1.Yes\n2.No\n";
             cin>>c26;
             while(!((c26==1)||(c26==2)))
             {
                 cout<<"Invalid Input!"<<endl;
                 cout<<"Enter again:"<<endl;
                 cin>>c26;
             }
             if(c24==1)
             {
                 Arts();
             }
             else if(c24==2)
             {
                 homepage10();
             }
        }
     }
     void Science()
     {
         system("cls");
         cout<<"\nEnter Stream u might want to try:\n1.P-C-M\n2.P-C-B"<<endl;
         cin>>choice;
         switch(choice)
                {
                    case 1:
                    {
                        int c2;
                        system("cls");
                        cout<<"\n\nEnter type:\n1.MHCET,MAINS AND ADVANCE \n2.DIPLOMA+ENGINEERING";
                        cin>>c2;
                        if(c2==1)
                        {
                            cout<<"\n\nTOP COLLEGES IN  MUMBAI:"<<endl;
                            cout<<"\n1.MITHIBAI COLLEGE";
                            cout<<"\n2.COLLEGE OF ARTS";
                            cout<<"\n3.K.C COLLEGE";
                            cout<<"\n4.S.K SOMANIA";
                            cout<<"\n5.RAMNIRANJAN JHUNJHUNWALA";
                            cout<<"\n\nTOP COACHING INSTITUTIONS THAT COULD MATCH UR ABOVE COLLEGE TIMINGS:";
                            cout<<"\n1.PACE";
                            cout<<"\n2.FITJEE";
                            cout<<"\n3.SPECTRUM";
                            exitgoback();

                        }
                        else if(c2==2)
                        {
                            cout<<"\n\nTOP POLYTECHNICS IN  MUMBAI:";
                            cout<<"\n1.ANGEL POLYTECHNIC";
                            cout<<"\n2.SHRI BHAGUBHAI MAFATLAL POLYTECHNIC";
                            cout<<"\n3.VEERMATA JIJABAI TECHNOLOGY";
                            cout<<"\n4.SOPHIA POLYTECHNIC";
                            cout<<"\n5.THAKUR POLYTECHNIC";
                            cout<<"\n\nTOP COACHING INSTITUTIONS THAT COULD MATCH UR ABOVE COLLEGE TIMINGS:";
                            cout<<"\n1.YOGESH TUTORIALS";
                            cout<<"\n2.MAHESH TUTORIALS";
                            cout<<"\n3.VIKRAMJIT CLASSES";
                            exitgoback();
                        }
                        break;
                    }
                    case 2:
                        {
                            cout<<"\n\nTOP COLLEGES IN  MUMBAI:";
                            cout<<"\n1.MITHIBAI COLLEGE";
                            cout<<"\n2. COLLEGE OF ARTS";
                            cout<<"\n3.K.C COLLEGE";
                            cout<<"\n4.S.K SOMANIA";
                            cout<<"\n5.RAMNIRANJAN JHUNJHUNWALA";
                            cout<<"\n\nTOP COACHING INSTITUTIONS THAT COULD MATCH UR ABOVE COLLEGE TIMINGS:";
                            cout<<"\n1.ALLEN";
                            cout<<"\n2.PACE";
                            cout<<"\n3.MINDSPACE";
                            exitgoback();

                        }
            }
     }
     void Commerce()
     {
         system("cls");
         cout<<"Top colleges in mumbai:"<<endl;
            if(percentage>=90)
            {
                 cout<<"\nCOLLEGES YOU MIGHT OPT FOR:"<<endl;
                 cout<<"1:NMIMS \n2:MITHIBAI  \n 3:JAI HIND COLLEGE";
                 cout<<"DO YOU MORE WANT INFO ABOUT THESE COLLEGES: Y FOR YES \nN FOR NO";
                 cin>>c22;
                 if(c22=='y'||c22=='Y')
                 {
                     cout<<"1.NMIMS :\n fees:30,000 \n place:Vile parle(west) \n seats:360"<<endl;
                     cout<<"\n2.MITHIBAI \n fees:18,345 \n place: Vile parle(west) \n seats:169"<<endl;
                     cout<<"\n3.JAI HIND  \n fees:2,250 \n place: Churchgate \n seats:250"<<endl;
                     exitgoback();
                 }
                 else if(c22=='n'||c22=='N')
                 {
                     exitgoback();
                 }
            }
         else if(percentage>=75)
         {
             cout<<"COLLEGES YOU MIGHT OPT FOR:"<<endl;
             cout<<"1:H.R COLLEGE \n2:K.C COLLEGE  \n3:SMT KUSUMTAI CHAUDHARI \n4:HINDUJA COLLEGE\n";
             cout<<"\nDO YOU MORE WANT INFO ABOUT THESE COLLEGES:\nY FOR YES \n N FOR NO";
             cin>>c22;
             if(c22=='y'||c22=='Y')
             {
                 cout<<"\n\n1.H.R.COLLEGE:\nfees:6,650 \nplace:Churchgate \nseats:160"<<endl;
                 cout<<"\n2.K.C.COLLEGE  \nfees:5,000 \nplace:Churchgate \nseats:260"<<endl;
                 cout<<"\n3.Smt Kusumtai Chaudhari  \nfees:2,780 \nplace: Bandra (east) \nseats:120"<<endl;
                 cout<<"\n4.HINDUJA COLLEGE  \nfees:3,000 \nplace: Churchgate \nseats:220"<<endl;
                 exitgoback();

             }
             else if(c22=='n'||c22=='N')
             {
                 exitgoback();
             }
         }
         else
         {
             cout<<"COLLEGES U MIGHT OPT FOR:"<<endl;
             cout<<" 1:GURU NANAK COLLEGE OF ARTS  \n 2:PRAVIN GANDHI \n 3:THHAKUR COLLEGE OF COMMERCE";
             cout<<"\nDO YOU MORE WANT INFO ABOUT THESE : \nY FOR YES \nN FOR NO";
             cin>>c22;
             if(c22=='y'||c22=='Y')
             {

                 cout<<"1.Guru Nanak COLLEGE   \nfees:5,008 \nplace: Sion\nseats:124"<<endl;
                 cout<<"\n2.pravin gandhi college of commerce  \nfees:18000 \nplace: vile parle(west) \nseats:120"<<endl;
                 cout<<"\n3.Thakur college   \nfees:15,000 \nplace: Kandivali(east) \nseats: 170"<<endl;
                 exitgoback();

             }
             else if(c22=='n'||c22=='N')
             {
                 exitgoback();
             }
         }
     }
     void Arts()
     {
             system("cls");
             if(percentage>=90)
             {
                 cout<<"COLLEGES U MIGHT OPT FOR:"<<endl;
                 cout<<"1:ST XAVIERS COLLEGE\n2:K J SOMAIYA  \n3:ST ANDREWS COLLEGE";
                 cout<<"\nDO YOU MORE WANT INFO ABOUT THESE COLLEGES: \nY FOR YES \n N FOR NO";
                 cin>>c22;
                 if(c22=='y'||c22=='Y')
                 {
                     cout<<"1.ST XAVIERS COLLEGE:\nfees:14,275 \nplace:Fort \nseats:360"<<endl;
                     cout<<"\n2. KJ SOMAIYA COLLEGE \nfees:28,345 \nplace: Ghatkopar(east) \nseats:269"<<endl;
                     cout<<"\n3. ST ANDREWS COLLEGE  \nfees:23,080 \nplace: Bandra (west) \nseats:450"<<endl;
                     exitgoback();
                 }
                 else if(c22=='n'||c22=='N')
                 {
                     exitgoback();
                 }
             }
             else if(percentage>=75)
             {
                 cout<<"COLLEGES YOU MIGHT OPT FOR:"<<endl;
                 cout<<"\n1:SIES COLLEGE OF ART\n2:SHRI L.R.TIWARI  \n3:SMT KUSUMTAI CHAUDHARI COLLEGE OF ARTS \n4:RIZVI COLLEGE OF ARTS";
                 cout<<"DO YOU MORE WANT INFO ABOUT THESE COLLEGES: Y FOR YES \n N FOR NO";
                 cin>>c22;
                 if(c22=='y'||c22=='Y')
                 {
                     cout<<"1.SIES COLLEGE OF ARTS:\nfees:6,650 \nplace:Sion(west) \nseats:60"<<endl;
                     cout<<"2. Shri L.R.Tiwari COLLEGE  \nfees:10,000 \n place: Thane\n seats:60"<<endl;
                     cout<<"3. Smt Kusumtai Chaudhari  \nfees:12,780 \nplace: Bandra (east) \nseats:120"<<endl;
                     cout<<"4. Rizvi COLLEGE of arts  \nfees:7,088 \nplace: Bandra (West) \nseats:138"<<endl;
                     exitgoback();

                 }
                 else if(c22=='n'||c22=='N')
                 {
                     exitgoback();
                 }
             }
             else
             {
                 cout<<"COLLEGES U MIGHT OPT FOR:"<<endl;
                 cout<<"1:St.FRANCIS INSTITUTE OF ARTS \n2:GURU NANAK COLLEGE OF ARTS  \n3:SOPHIA COLLEGE FOR WOMEN \n4:KIRTI M DOONGURSEE";
                 cout<<"DO YOU MORE WANT INFO ABOUT THESE COLLEGES: \nY FOR YES \n N FOR NO\n";
                 cin>>c22;
                 if(c22=='y'||c22=='Y')
                 {
                     cout<<"1.St Francis institute of arts:\nfees:10,000 \nplace:Thane \nseats:100"<<endl;
                     cout<<"\n2.Guru Nanak COLLEGE of arts  \nfees:5,008 \nplace: Sion\nseats:124"<<endl;
                     cout<<"\n3.Sophia college for women  \nfees:18000 \nplace: Fort \nseats:120"<<endl;
                     cout<<"\n4.Kirti m.doongursee  \nfees:5,841 \n place: Dadar(West) \nseats:170"<<endl;
                     exitgoback();

                 }
                 else if(c22=='n'||c22=='N')
                 {
                     exitgoback();
                 }
             }
     }
};

class project12
{
    static int mks;
    static int ent;
    static char col;
    static int choice4;
    int goback12;
public:
    void base();
    void science();
    void commerce();
    void arts();
    void exitgoback12();

};
int project12::choice4;
int project12::ent;
int project12::mks;
char project12::col;
void project12::exitgoback12()
{
        cout<<"\n\n1.Exit\n2.Go back\n";
        cin>>goback12;
        while(!((goback12==1)||(goback12==2)))
        {
            cout<<"\nInvalid Input!";
            cout<<"\nEnter again:"<<endl;
            cin>>goback12;
        }
        if(goback12==1)
        {
            cout<<"\n\nThank you! Do visit again!";
        }
        if(goback12==2)
        {
            base();
        }
}
void project12::base()
{
    system("cls");
    cout<<"\nYour base stream\n1.Science\n2.Commerce\n3.Arts\n";
    cin>>choice4;
    while(!((choice4==1)||(choice4==2)||choice4==3))
    {
        cout<<"\nInvalid Input!"<<endl;
        cout<<"Enter again:"<<endl;
        cin>>choice4;
    }
    if(choice4==1)
    {
        science();
    }
    else if(choice4==2)
    {
        commerce();
    }
    else if(choice4==3)
    {
        arts();
    }
}
void project12::science()  //science function
{
    system("cls");
    cout<<"\nWhich entrance exam have you given?\nPress \n1:JEE \n2:NEET \n3:NATA"<<endl;
    cin>>ent;
    while(!((ent==1)||(ent==2)||(ent==3)))
    {
        cout<<"Invalid Input!"<<endl;
        cout<<"Enter again!"<<endl;
        cin>>ent;
    }
    cout<<"\nEnter entrance exam score percent"<<endl;
    cin>>mks;
    system("cls");
    switch(ent)
    {
        case 1: //JEE
            {
                if(mks>=90)
                {
                    cout<<"Colleges available for you are: \n\n1.IIT-B \n2.VJTI \n3.DJ Sanghvi";
                    cout<<"\n\nDo you want more information about the colleges? If yes then press y\n";
                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"IIT-B:Location: Powai \nFees: with hostel(115250) without hostel(105700)\nNumber of seats: 929 seats +seats reserved for the backward classes\nVJTI\nLocation:Matunga\nFees:83804\nNumber of seats: 60 per branch\nDJ Sanghvi\nLocation:Juhu\nFees:115161\nNumber of seats: 120 per branch";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }
                }

                if(mks<90 && mks>=70)
                {
                    cout<<"\n\nColleges available for you are: \n\n1.KJ Somaiya College of Engineering \n2.NMIMS-MPSTME";
                    cout<<"\n\nDo you want more information about the colleges? If yes then press y\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"\nKJ Somaiya\nLocation: Vidya Vihar \nFees: 171374\nNumber of seats: 138 per branch\n\nNMIMS- MPSTME\nLocation: Juhu\nFees: 180000 \nNumber of seats: 60 per branch";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }

                }

                if(mks<70 && mks>=50)
                {
                    cout<<"Colleges available for you are: \n1.Rajiv Gandhi Institute of Technology \n2.Sardar Patel College of Engineering \n3.Thakur College of Engineering ";
                    cout<<"\nDo you want more information about the colleges? If yes then press y\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"Rajiv Gandhi Institute of Technology\nLocation: Versova\nFees:105000\nNumber of seats:50\nSardar Patel College of Engineering \nLocation: Andheri\nFees: 105000\nNumber of seats:60 per branch\nThakur College of Engineering\nLocation: Kandivali\nFees: 120000\nNumber of seats: 120 per branch";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }
                }
                if(mks<50)
                {
                   cout<<"Colleges available for you are: \n1.Don Bosco Institute of Technology \n2.Rizvi College of Engineering \n3.Shah and Anchor College of Engineering";
                   cout<<"\nDo you want more information about the colleges? If yes then press y\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"Don Bosco Institute of Technology\nLocation: Kurla\nFees: 150000\n Number of seats: 120 per branch\nRizvi College of Engineering\nLocation: Bandra\nFees:49500\nNumber of seats: 60 per branch\nShah and Anchor College of Engineering\nLocation: Chembur\nFees:105704\nNumber of seats: 120 per branch";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }
                }

                break;
            }

         case 2:  //NEET
            {
                if(mks>=90)
                {
                    cout<<"Colleges available for you are: \n1.KEM \n2.Tata Memorial Hospital\n";
                    cout<<"\nDo you want more information about the colleges? If yes then press y\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"\nKEM\nLocation: Parel\nFees:89125\nNumber of seats:180 \n\nTata Memorial Hospital\nLocation: Parel\nFees: 100000\nNumber of seats: 450";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }
                }

                if(mks<90 && mks>=70)
                {
                    cout<<"Colleges available for you are: \n1.Lokmanya Tilak Municipal Medical College \n2.Grant Medical College \n3.RN Cooper Medical College";
                    cout<<"\nDo you want more information about the Colleges? If yes then press y\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"Lokmanya Tilak Municipal Medical College\nLocation: Sion\nFees: 60000\nNumber of seats: 497\n\nGrant Medical College\nLocation: Mazgaon\nFees: 60000\nNumber of seats: 449";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }
                }

                if(mks<70 && mks>=50)
                {
                    cout<<"Colleges available for you are: \n1.Nair Hospital and College\n2.Ali Yavar Jung National College ";
                    cout<<"\nDo you want more information about the Colleges? If yes then press y\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"\n\nNair Hospital and College\nLocation: Maratha Mandir\nFees:50000\nNumber of seats:450\n\nAli Yavar Jung National College\nLocation: Bandra\nFees: 25000\nNumber of seats: 40 per stream";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }
                }
                if(mks<50)
                {
                   cout<<"Colleges available for you are: \n1.Seth GS Medical College \n2.Topiwala National Medical College \n3.Podar Medical College";
                    cout<<"\nDo you want more information about the Colleges? If yes then press y\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"\n\nSeth GS Medical College\nLocation: Parel\nFees:400000 for 5yrs and 5months course\nNumber of seats: 250\nTopiwala National Medical College\nLocation: A.L. Nair Road\nFees:50000\nNumber of seats:120\nPodar Medical College\nLocation: Worli\nFees: 43400\nNumber of seats: 60 ";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }
                }

                break;
            }

         case 3:  //NATA
            {
                if(mks>=90)
                {
                    cout<<"Colleges available for you are: \n1.Sir JJ College of Architecture \n2.Rizvi College of Architecture \n3.NMIMS";
                     cout<<"\nDo you want more information about the Colleges? If yes then press y\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"\n\nSir JJ College of Architecture\nLocation: Fort\nFees: 47470 for 5years course\nNumber of seats: 67\n\nRizvi College of Architecture\nLocation: Bandra\nFees: 40\nNumber of seats: 88182";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }
                }

                if(mks<90 && mks>=70)
                {
                    cout<<"\nColleges available for you are: \n1.IES College of Architecture \n2.Academy of Architecture \n3.Amity University";
                    cout<<"\nDo you want more information about the Colleges? If yes then press y\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"\n\nIES College of Architecture\nLocation: Bandra\nFees: 750000\nNumber of seats: 60\n\nAcademy of Architecture\nLocation: Prabhadevi\nFees:157500\nNumber of seats: 40\n\nAmity University\nLocation: Panvel\nFees: 200000\nNumber of seats:80";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }

                }

                if(mks<70 && mks>=50)
                {
                    cout<<"Colleges available for you are: \n1.Dr Baliram Hiray College of Architecture \n2.Rachna Sansad School of Design \n3.Thakur School of Architecture";
                    cout<<"\nDo you want more information about the Colleges? If yes then press y\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"Dr Baliram Hiray College of Architecture \nLocation: Bandra\nFees: 86000\nNumber of seats: 80\nRachna Sansad School of Design\nLocation: Prabhadevi\nFees: 49300\nNumber of seats: 40\nThakur School of Architecture\nLocation: Kandivali\nFees: 965000\nNumber of seats: 80";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }
                }
                if(mks<50)
                {
                   cout<<"Colleges available for you are: \n1.CTES College of Architecture \n2.Kamla Raheja College of Architecture \n3.LS Raheja College of Architecture";
                   cout<<"\nDo you want more information about the Colleges? If yes then press y\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"CTES College of Architecture \nLocation: Chembur\nFees: 40000\nNumber of seats: 40\nKamla Raheja College of Architecture \nLocation:\nFees:\nNumber of seats:\nLS Raheja College of Architecture\nLocation:\nFees:\nNumber of seats:";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }
                }
            }
    }
}

void project12::commerce()  //COMMERCE FUNCTION
{
    system("cls");
    cout<<"\nWhich entrance exam have you given?";
    cout<<"\n1:CAT \n2:CPT "<<endl; //\n3:CFA\n4:CS
    cin>>ent;
    while(!((ent==1)||(ent==2)))
    {
        cout<<"Invalid Input!"<<endl;
        cout<<"Enter again:"<<endl;
        cin>>ent;
    }
    cout<<"\nEnter entrance exam score percent"<<endl;
    cin>>mks;
    system("cls");
    switch(ent)
    {
        case 1:  //CAT
        {
                if(mks>=70)
                {
                    cout<<"Colleges available for you are: \n1.NMIMS \n2.KJ Somaiya Institute of Management Studies and Research"<<endl;
                    cout<<"\nDo you want more information about the Colleges? If yes then press y\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"NMIMS\nFees: 17,50,000\nPlace: Juhu\nSeats: 500\n\nKJ Somaiya Institute of Management Studies and Research\nFees:85,000\nPlace: Ghatkopar(east)\nSeats: 200";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }
                }

                if(mks<70 && mks>=50)
                {
                    cout<<"Colleges available for you are: \n1.Symbiosis Institute of Business Management \n2.Narsee Monjee Institute of Management\n3.Indira Institute of Management";
                    cout<<"\nDo you want more information about the Colleges? If yes then press y\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"\nSymbiosis Institute of Business Management\nFees: 20.50 L\nPlace: Pune\nSeats:150\n\nNarsee Monjee Institute of Management\nFees: 1.36L\nPlace: Juhu\nSeats: 1320\n\nIndira Institute of Management\nFees: 6,70,000\nPlace: Navi mumbai\nSeats: 180";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }
                }
                if(mks<50)
                {
                   cout<<"Colleges available for you are: \n1.Balaji Institute of Telecom and Management \n2.Arihant Institute of Management \n3.Lala Lajpat Rai Institute of Management";
                   cout<<"\nDo you want more information about the Colleges? If yes then press y\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"Balaji Institute of Telecom and Management\nFees: 8.1 L\nPlace: Pune\nSeats: 120\n\nArihant Institute of Management\nFees: ₹186,000\nPlace: Pune\nSeats: 120\n\nLala Lajpat Rai Institute of Management\nFees: 1.42 L\nPlace: Mahalaxmi\nSeats: 190";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }
                }

                break;
        }

        case 2:  //CPT
        {
                if(mks>=70)
                {
                    cout<<"Colleges available for you are: \n1.NMIMS \n2.KJ Somaiya Institute of Management Studies and Research ";
                    cout<<"\nDo you want more information about the Colleges? If yes then press y\n";
                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"\nNMIMS\nFees: 17.5L\nPlace: Juhu\nSeats: 500\n\nKJ Somaiya Institute of Management Studies and Research\nFees: 85,000\nPlace: Ghatkopar(east)\nSeats: 200";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }
                }
                else if(mks<70 && mks>=50)
                {
                    cout<<"Colleges available for you are: \n1.Symbiosis Institute of Business Management \n2.Narsee Monjee Institute of Management3.Indira Institute of Management";
                    cout<<"\nDo you want more information about the Colleges? If yes then press y\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"Symbiosis Institute of Business Management\nFees: 20.50 L\nPlace: Pune\nSeats:150\n\nNarsee Monjee Institute of Management\nFees: 1.36L\nPlace: Juhu\nSeats: 1320\n\nIndira Institute of Management\nFees: 6,70,000\nPlace: Navi mumbai\nSeats: 180";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }

                }
                if(mks<50)
                {
                   cout<<"Colleges available for you are: \n1.Balaji Institute of Telecom and Management \n2.Arihant Institute of Management \n3.Lala Lajpat Rai Institute of Management";
                   cout<<"\nDo you want more information about the Colleges? If yes then press y\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"Balaji Institute of Telecom and Management\nFees: 8.1 L\nPlace: Pune\nSeats: 120\n\nArihant Institute of Management\nFees: ₹186,000\nPlace: Pune\nSeats: 120\n\nLala Lajpat Rai Institute of Management\nFees: 1.42 L\nPlace: Mahalaxmi\nSeats: 190";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }

                }

        }

    }
}

void project12::arts()  //ARTS FUNCTION
{
    system("cls");
    cout<<"Which entrance exam have you given?";
    cout<<"\nPress \n1:Design(NIFT/NID) \n2:CLAT \n3:CHAT";
    cin>>ent;
    while(!((ent==1)||(ent==2)||(ent==3)))
    {
        cout<<"Invalid Input!"<<endl;
        cout<<"Enter again!";
        cin>>ent;
    }
    cout<<"\nEnter entrance exam score percent"<<endl;
    cin>>mks;
    system("cls");
    switch(ent)
    {
        case 1:  //NIFT/NID
        {
                if(mks>=70)
                {
                    cout<<"Colleges available for you are: \n1.National Institute of Design \n2.National Institute of Fashion Technology \n3.Industrial Design Centre(IIT) ";
                    cout<<"\nDo you want more information about the Colleges? If yes then press y\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"National Institute of Design\nFees:1.2lakhs\nPlace:Ahmedabad,Bengaluru\nSeats:100\n\nNational Institute of Fashion Technology\nFees:1,42,300\nPlace:jodhpur,bhubneshwar,srinagar\nSeats:180\n\nIndustrial Design Centre(IIT)\nFees: ₹52,400\nPlace: powai\nSeats:51";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }
                }

                if(mks<70 && mks>=50)
                {
                    cout<<"Colleges available for you are: \n1.JD Institute of Fashion Technology \n2.International Institute of Fashion Design \n3.St Francis Institute of Art and Design";
                    cout<<"\nDo you want more information about the Colleges? If yes then press y & n for no\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"JD Institute of Fashion Technology\nFees: 2,50000\nPlace: vile parle(west)\nSeats:130\n\nInternational Institute of Fashion Design\nFees: 1,10,000 \nPlace: Andheri\nSeats: 216\n\nSt Francis Institute of Art and Design\nFees:  1,20,000\nPlace: Borivali(west)\nSeats:100";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }
                }
                if(mks<50)
                {
                   cout<<"Colleges available for you are: \n1.Aditya College of Design Studies \n2.Rafelles Design College \n3.JJ Institute of Applied Arts";
                   cout<<"\nDo you want more information about the Colleges? If yes then press y\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"Aditya College of Design Studies\nFees:1,30,000\nPlace: Borivali(west)\nSeats:600\n\nRafelles Design College\nFees: 21,00,000\nPlace: andheri(east)\nSeats:24000\n\nJJ Institute of Applied Arts\nFees: ₹300,000\nPlace: Fort\nSeats: 285";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }
                }

            break;
        }

        case 2:  //CLAT
        {
                if(mks>=70)
                {
                    cout<<"Colleges available for you are: \n1.Government Law College \n2.KC Law College \n3.Dr. Ambedkar College of Law ";
                    cout<<"\nDo you want more information about the Colleges? If yes then press y\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"Government Law College\nFees:5000\nPlace:churchgate\nSeats: 300\n\nKC Law College\nFees:3550\nPlace:churchgate\nSeats:300\n\nDr.Ambedkar College of Law\nFees:21.97K\nPlace: Wadala\nSeats: 80";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }
                }

                if(mks<70 && mks>=50)
                {
                    cout<<"Colleges available for you are: \n1.Rizvi Law College \n2.NMIMS Law College \n3.Jitendra Chauhan College of Law";
                    cout<<"\nDo you want more information about the Colleges? If yes then press y\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"Rizvi Law College\nFees: 115,000\nPlace: Fort\nSeats:180\n\nNMIMS Law College\nFees:17.5\nPlace: Juhu\nSeats: 60\n\nJitendra Chauhan College of Law\nFees:35000\nPlace: vile parle(W)\nSeats: 15000";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }
                }
                if(mks<50)
                {
                   cout<<"Colleges available for you are: \n1.Lords Universal College \n2.PES Law College \n3.KES Law College";
                   cout<<"\nDo you want more information about the Colleges? If yes then press y\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"Lords Universal College\nFees: 11,275\nPlace:Goregaon West\nSeats:60\n\nPES Law College\nFees:30,000\nPlace:Banglore\nSeats:240\n\nKES Law College\nFees:96,000\nPlace: Kandivali\nSeats:120";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }
                }

            break;
        }

        case 3:
        {
                if(mks>=70)
                {
                    cout<<"Colleges available for you are: \n1.Rizvi College of Hotel Management \n2.Appejay Institute of Hospitality \n3.Institute of Hotel Management Catering Technology and Applied Nutrition ";
                    cout<<"\nDo you want more information about the Colleges? If yes then press y\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"Rizvi College of Hotel Management\nFees:1,36,000\nPlace: Bandra west\nSeats:110\n\nAppejay Institute of Hospitality\nFees:1,65,000\nPlace: Navi mumbai\nSeats:85\n\nInstitute of Hotel Management Catering Technology and Applied Nutrition\nFees:103,900\nPlace:Dadar west\nSeats:124";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }
                }

                if(mks<70 && mks>=50)
                {
                    cout<<"Colleges available for you are: \n1.Mumbai College of Hotel Management and Catering Technology  \n2.Indian Institute of Hospitality and Management \n3.Dr. BMN College of Home Science ";
                    cout<<"\nDo you want more information about the Colleges? If yes then press y\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"Mumbai College of Hotel Management and Catering Technology\nFees:75,000\nPlace:Bhayender(west)\nSeats:65\n\nIndian Institute of Hospitality and Management\nFees:49,500\nPlace:Vasai(west)\nSeats:78\n\nDr. BMN College of Home Science\nFees:35,000\nPlace:Matunga\nSeats:121";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }
                }

                if(mks<50)
                {
                    cout<<"Colleges available for you are: \n1.La Sphere School of Hotel Management \n2.Raheja Institute of Hotel Management";
                    cout<<"\nDo you want more information about the Colleges? If yes then press y\n";

                    cin>>col;
                    if(col=='y'||col=='Y')
                    {
                        cout<<"La Sphere School of Hotel Management\nFees:370\nPlace: Dombivili(east)\nSeats:60\nRaheja Institute of Hotel Management\nFees:75,000\nPlace:Bandra(east)\nSeats:105";
                        exitgoback12();
                    }
                    else
                    {
                        exitgoback12();
                    }
                }

            break;
        }
    }
}


class Data:public project10,public project12
{
    string username,fn,ln,cardn,expiryd,password,email_id,mobile_number;
    int choice,choice1,choice2;
    char aptitude_test,cvv;
public:
    Data()
    {
        username="sohampatel002";
        password="pass@123";
    }
    void take_data()
    {
        system("cls");
        cout<<"               Guide to Grow             "<<endl;
        cout<<"\n\n1.Log In\n2.Create Account\n3.Exit\n";
        cin>>choice;
        while(!((choice==1) || (choice==2) || (choice==3)))
        {
            cerr<<"\nWrong Input!"<<endl;
            cout<<"Enter again: ";
            cin>>choice;
        }
        if(choice==1)
        {
            signin();
        }
        else if(choice==2)
        {
            create();
        }
        else if(choice==3)
        {
            cout<<"\nThank you! Do visit again :)\n";
        }
    }
    int getchoice()
    {
        return choice;
    }
    void signin()
    {
        system("cls");
        cout<<endl<<"                  Sign In                 "<<endl;
        inputdata:
        {
            cout<<"\nUser name:"<<endl;
            cin>>username;
            cout<<"\nPassword:"<<endl;
            cin>>password;
            int c1=0,c2=0;
            ifstream fin1;
            fin1.open("usernamepass.txt",ios::app);
            while(!fin1.eof())
            {
                string user;
                getline(fin1,user);
                if(user==username)
                {
                    c1++;
                }
            }
            fin1.close();
            if(c1>=1)
            {
                ifstream fin2;
                fin2.open("usernamepass.txt",ios::app);
                while(!fin2.eof())
                {
                    string pass;
                    getline(fin2,pass);
                    if(pass==password)
                    {
                        c2++;
                    }
                }
                fin2.close();
                if(c2>=1)
                {
                    cout<<"Sign in Successful!";
                    homepage();
                }
                else
                {
                    cout<<"\nInvalid Password!";
                    goto inputdata;
                }
            }
            else
            {
                cout<<"\nCouldn't find account! Invalid user name.";
                goto inputdata;
            }
        }
    }
    void create()
    {
        system("cls");
        cout<<"              Create Account                "<<endl;
        cout<<"First Name:"<<endl;
        cin>>fn;
        cout<<"\nLast Name:"<<endl;
        cin>>ln;
        cout<<"\nMobile number:"<<endl;
        cin>>mobile_number;
        while(mobile_number.size()!=10)
        {
            cout<<"Invalid Input! Length of mobile number should be 10 digits"<<endl;
            cout<<"Enter again:"<<endl;
            cin>>mobile_number;
        }
        cout<<"\nEmail Id:"<<endl;
        cin>>email_id;
        cout<<"\nUser name:"<<endl;
        cin>>username;
        testusername:
            ifstream fin;
            fin.open("usernamepass.txt",ios::app);
            while(!fin.eof())
            {
                string user;
                while(fin>>user)
                {
                    if(user==username)
                    {
                        cout<<"Not available!"<<endl;
                        cout<<"Try with another User name:"<<endl;
                        cin>>username;
                        goto testusername;
                    }
                }
            }
        fin.close();
        int j;
        passcheck:
        cout<<"\nPassword:"<<endl;
        cin>>password;
        while(password.size()<7)
        {
            cout<<"\nMinimum length of password should be 7 characters"<<endl;
            cout<<"Enter Password again:"<<endl;
            cin>>password;
        }
        string pass_check;
        cout<<"\nConfirm Password:"<<endl;
        cin>>pass_check;
        while(password!=pass_check)
        {
            cout<<"\nThe passwords don't match!";
            cout<<"\nTry again\n";
            goto passcheck;
        }
        int cardc;
        cout<<"\nPackage: 1000/year"<<endl;
        cout<<"Do you want to proceed with the payment?\n1.Yes\n2.No"<<endl;
        cin>>cardc;
        while(!((cardc==1)||(cardc==2)))
        {
            cout<<"Invalid Input!"<<endl;
            cout<<"Enter again:"<<endl;
            cin>>cardc;
        }
        if(cardc==1)
        {
            system("cls");
            cout<<"\n\n              Payment Options                 "<<endl;
            cout<<"1.Debit card\n2.Credit card"<<endl;//1000 for year
            cin>>choice1;
            while(!((choice1==1)||(choice1==2)))
            {
                cout<<"Invalid Input!"<<endl;
                cout<<"Enter again:"<<endl;
                cin>>choice1;
            }
            switch(choice1)
            {
            case 1:
                {
                    card();
                    break;
                }
            case 2:
                {
                    card();
                    break;
                }
            default:
                {
                    cout<<"Wrong input!";
                    break;
                }
            }

        }
        else if(cardc==2)
        {
            take_data();
        }
    }
    void card()
    {
        cout<<"\nCard number:"<<endl;
        cin>>cardn;
        while(!((cardn.size()==12)||(cardn.size()==13)||(cardn.size()==14)||(cardn.size()==15)||(cardn.size()==16)||(cardn.size()==19)))
        {
            cerr<<"Invalid card number!";
            cout<<"\nCard number:"<<endl;
            cin>>cardn;
        }
        cout<<"\nExpiry date (mm/yy):"<<endl;
        cin>>expiryd;
        while(expiryd.size()!=5)
        {
            cout<<"\nThe date should be in the format (mm/yy)"<<endl;
            cin>>expiryd;
        }
        string cvv2;
        cout<<"\nCVV:"<<endl;
        cvv=_getch();
        while(cvv!=13)
        {
            cvv2.push_back(cvv);
            cout<<"*";
            cvv=_getch();
        }
        int cv;
        cv=cvv2.size();
        while(cv!=3)
        {
            string cvv3;
            cout<<"\nInvalid Input!";
            cout<<"\nTry again:"<<endl;
            cvv=_getch();
            while(cvv!=13)
            {
                cvv3.push_back(cvv);
                cout<<"*";
                cvv=_getch();
            }
            cv=cvv3.size();
        }
        cout<<"\nPayment Successful!\n";
        ofstream fout;
        fout.open("usernamepass.txt",ios::app);
        fout<<endl<<username<<endl;
        fout<<password;
        fout.close();
        homepage();
    }
    void homepage()
    {
        system("cls");
        cout<<"            Home page             "<<endl;
        cout<<"1.After 10th std\n2.After 12th std\n3.Log out"<<endl;
        cin>>choice2;
        while(!((choice2==1) || (choice2==2) || (choice2==3)))
        {
            cout<<"\nInvalid Input!"<<endl;
            cout<<"Enter again:"<<endl;
            cin>>choice2;
        }
        if(choice2==1)
        {
            project10::input10();
        }
        else if(choice2==2)
        {
            project12::base();
        }
        else if(choice2==3)
        {
            take_data();
        }
    }
};

int main()
{
    int a;
    Data obj;
    obj.take_data();
    return 0;
}
